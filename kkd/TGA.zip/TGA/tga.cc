//
// Created by krrer on 04.05.22.
//

#include "inc/tga.hpp"
