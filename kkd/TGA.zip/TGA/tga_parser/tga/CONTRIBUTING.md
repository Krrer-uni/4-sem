By submitting a pull request, you represent that you have the right to
license your contribution to the Tga project owners and the community,
agree by submitting the patch that your contributions are licensed under
the [Tga license](https://raw.githubusercontent.com/aseprite/tga/main/LICENSE.txt),
and agree to future changes to the licensing.
