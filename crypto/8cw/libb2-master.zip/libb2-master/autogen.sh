#! /bin/sh
autoreconf -fvi
